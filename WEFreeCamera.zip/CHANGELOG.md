# WE 1.59
# 1.3.1
Updated for the game version 1.59
# WE 1.58
# 1.3.0
No longer snaps back in the match setup
Added a different camera movement mode
# 1.2.1
Updated for the game version 1.58
# WE 1.56
## 1.2.0
Improved compatibility with the Custom Arena Camera Mod
Added camera angle saving and loading
Added changing the camera field of view
## 1.1.0
Fixed scene transitions: the free camera now should autodisable itself when the game switches to a different scene.
Added compatibility with [WE_Street's Custom Arena Camera Mod](https://thunderstore.io/c/wrestling-empire/p/WE_Street/Custom_Arena_Camera_Mod/)
## 1.0.1
Audio and performance fixes