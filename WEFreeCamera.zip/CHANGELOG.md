# 1.0.1
Audio and performance fixes